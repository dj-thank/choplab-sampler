# ChopLab Complete Bundle

作成日: 2026-07-15

このZIPは、現在の作業環境で確認できたChopLab関連成果物をまとめたものです。

## 内容

- `Pro/ChopLabAndroid/`
  - Oboe向けC++サンプラーコア
  - JNIブリッジ
  - プロジェクト保存
  - ステレオオフラインレンダリング／ステム処理
  - MIDI制御
  - README、機能表、アーキテクチャ資料
- `MVP/ChopLabAndroid-MVP.zip`
  - 前段階のMVPプロジェクトZIP
- `MVP/ChopLabAndroid-MVP.sha256`
  - MVP ZIPのSHA-256
- `FILELIST.txt`
  - 同梱ファイル一覧
- `SHA256SUMS.txt`
  - 各ファイルのSHA-256

## 重要事項

Proフォルダーには、この環境で現存していた8つのPro版ソース／資料ファイルをそのまま収録しています。Android Studioの完全なプロジェクト構成に必要なGradle設定、Manifest、Resources、Compose UIなどは、現存するProフォルダー内では確認できませんでした。そのため、Proフォルダー単独をそのままビルド可能な完成プロジェクトとは表現していません。

MVP ZIPは別途そのまま同梱しているため、元のMVP構成も保持されています。
